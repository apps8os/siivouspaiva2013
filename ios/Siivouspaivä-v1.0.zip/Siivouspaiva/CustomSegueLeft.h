//
//  CustomSegueLeft.h
//  CustomSegue
//
//  Created by Fabian on 7/5/12.
//  Copyright (c) 2012 Fabian Häusler. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomSegueLeft : UIStoryboardSegue

@end
