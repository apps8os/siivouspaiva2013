//
//  ThirdViewController.m
//  Siivouspaiva
//
//  Created by Fabian on 25.03.13.
//  Copyright (c) 2013 Fabian Häusler. All rights reserved.
//

#import "ThirdViewController.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
