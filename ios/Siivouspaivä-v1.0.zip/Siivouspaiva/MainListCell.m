//
//  MainListCell.m
//  Siivouspaiva
//
//  Created by Fabian on 08.05.13.
//  Copyright (c) 2013 Fabian. All rights reserved.
//

#import "MainListCell.h"

@implementation MainListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
