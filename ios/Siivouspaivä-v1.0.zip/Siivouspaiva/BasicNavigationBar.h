//
//  BasicNavigationBar.h
//  Siivouspaiva
//
//  Created by Fabian on 02.04.13.
//  Copyright (c) 2013 Fabian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicNavigationBar : UINavigationBar
{
    IBOutlet UINavigationBar *myMainNavigationBar;
}
@property(nonatomic, strong) UINavigationBar *myMainNavigationBar;
@end
